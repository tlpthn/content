﻿=== User registration & user profile - Profile Builder ===
Contributors: cozmoslabs, reflectionmedia, sareiodata, adispiac, madalin.ungureanu, iova.mihai, barinagabriel
Donate link: http://www.cozmoslabs.com/wordpress-profile-builder/
Tags: user registration, user profile, user registration form, user fields, extra user fields, edit profile, user custom fields, front-end login, front-end edit profile, front-end user registration, email confirmation, login form, content restriction, restrict content
Requires at least: 3.1
Tested up to: 4.9.1
Stable tag: 2.7.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Simple to use profile plugin allowing front-end login, user registration and edit profile by using shortcodes. Built in Role Editor grants you control over user roles and capabilities on your site. Add Content Restriction based on user role.
 
== Description ==

**Profile Builder is WordPress user registration done right.**

Easy to use profile plugin allowing front-end login, user registration and edit profile by using shortcodes.

Restrict Content based on user role or logged in status & manage user roles and capabilities using the built in Role Editor.

**Like this plugin?** Consider leaving a [5 star review](https://wordpress.org/support/view/plugin-reviews/profile-builder?filter=5).

It lets you customize your website by adding a front-end menu for all your users, giving them a more flexible way to modify their user profile or register users (front-end user registration).
Users with administrator rights can customize basic user fields or add custom user fields to the front-end forms.

To achieve this, simply create a new page and give it an intuitive name(i.e. Edit Profile).
Now all you need to do is add the following shortcode: [wppb-edit-profile].
Publish the page and you are done!

= Front-end User Registration, Login, Edit Profile and Password Recovery Shortcodes =
You can use the following shortcode list:

* **[wppb-edit-profile]** - to grant users front-end access to their user profile (requires user to be logged in).
* **[wppb-login]** - to add a front-end login form.
* **[wppb-logout]** - to add logout functionality.
* **[wppb-register]** - register users via a front-end register form.
* **[wppb-recover-password]** - to add a password recovery form.
* **[wppb-restrict]**Content to restrict**[/wppb-restrict]** - to restrict blocks of content

Users with administrator rights have access to the following features:

* drag & drop to reorder user profile fields
* enable **Email Confirmation** (on registration users will receive a notification to confirm their email address).
* allow users to **Log-in with their Username or Email**
* enforce a **minimum password length** and **minimum password strength** (using the default WordPress password strength meter)
* assign users a specific role at registration (using **[wppb-register role="desired_role"]** shortcode argument for the register form)
* redirect users after login, register and edit-profile using redirect_url shortcode argument ( e.g **[wppb-login redirect_url="www.example.com"]** )
* add register and lost password links below the login form (using **[wppb-login register_url="www.example.com" lostpassword_url="www.example.com"]** shortcode arguments)
* customizable user login widget
* add a custom stylesheet/inherit values from the current theme or use the default one built into this plugin.
* chose which user roles view the admin bar in the front-end of the website (Admin Bar Settings page).
* select which profile fields users can use in frontend.
* extended functionality available via [Add-ons](http://www.cozmoslabs.com/profile-builder-add-ons/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree)
* role editor: add, remove, clone and edit roles and also capabilities for these roles.
* reacaptcha for Profile Builder forms and WordPress default forms
* user role select field on register and edit profile forms
* content restriction - restrict content based on user role or logged in status

**PROFILE BUILDER PRO**

The [Pro version](http://www.cozmoslabs.com/wordpress-profile-builder/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) has the following extra features:

* Create Extra User Fields (Heading, Input, Hidden-Input, Checkbox, Agree to Terms Checkbox, Radio Buttons, DatePicker, Textareas, WYSIWYG, reCAPTCHA, Upload fields, Selects, User Role Select, Country Select, Timezone Select, Avatar Upload, Map, HTML, Phone, Time Picker, ColorPicker, Custom Validation field, Currency Select)
* Add Avatar Upload for users
* Support for Conditional Fields
* Front-end User Listing (fully customizable, sorting included)
* Create Multiple User Listings
* Custom Redirects
* Multiple Registration Forms (set up multiple registration forms with different profile fields for certain user roles)
* Multiple Edit Profile Forms
* Admin Approval
* Email Customizer (Personalize all emails sent to your users or admins; customize default WordPress registration email)
* Advanced Modules (e.g. custom redirects, user listing, multiple registration forms etc.)
* Access to support forums and documentation
* 1 Year of Updates / Priority Support

[Find out more about Profile Builder PRO](http://www.cozmoslabs.com/wordpress-profile-builder/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree)


= Add-ons =

For more functionality check out [Profile Builder Add-ons page](http://www.cozmoslabs.com/profile-builder-add-ons/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree)

**Free Add-ons**

* [Custom Login Page Templates](https://www.cozmoslabs.com/add-ons/custom-login-page-templates/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - customize the default WordPress login page with your own design.
* [Client Portal](https://www.cozmoslabs.com/add-ons/client-portal/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - create private pages for your website users that only an administrator can edit.
* [Email Confirmation Field](http://www.cozmoslabs.com/add-ons/email-confirmation-field/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - check if the email address entered matches the first one, making sure a user submits a valid and correct email address
* [Multiple Admin E-mails](http://www.cozmoslabs.com/add-ons/multiple-admin-e-mails/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - send user notification emails to multiple email addresses
* [Custom CSS Classes on Fields](http://www.cozmoslabs.com/add-ons/custom-css-classes-fields/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - add custom CSS classes for fields
* [Numbers and Phone Validation](http://www.cozmoslabs.com/add-ons/numbers-phone-validation/?utm_source=wp.org&utm_medium=pms-description-page&utm_campaign=PMSFree) - zip codes, phone numbers, ID's require the custom input field to contain numbers only
* [Import and Export](http://www.cozmoslabs.com/add-ons/import-export/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - allows you to import and export all Profile Builder Settings data
* [Passwordless Login](http://www.cozmoslabs.com/add-ons/passwordless-login/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - allow your users to login without a password
* [Maximum Character Length](http://www.cozmoslabs.com/add-ons/maximum-character-length/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - set a maximum character length for custom input or textarea fields
* [Labels Edit](http://www.cozmoslabs.com/add-ons/labels-edit/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - easily edit all Profile Builder labels
* [Placeholder Labels](http://www.cozmoslabs.com/add-ons/placeholder-labels/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - replace labels with placeholders in Profile Builder form
* [Select2](http://www.cozmoslabs.com/add-ons/select2/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - create select fields with search and filter functionality

**Premium Add-ons**

* [WooCommerce Sync](http://www.cozmoslabs.com/add-ons/woocommerce-sync/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - integrates Profile Builder with WooCommerce, allowing you to manage Shipping and Billing fields from WooCommerce with PB and more
* [Social Connect](http://www.cozmoslabs.com/add-ons/social-connect/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - enable social login on your website, users can login with Facebook, Google+ or Twitter
* [Custom Profile Menus](http://www.cozmoslabs.com/add-ons/custom-profile-menus/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - add custom menu items like Login/Logout or just Logout button and Login/Register/Edit Profile in iFrame Popup
* [MailChimp](http://www.cozmoslabs.com/add-ons/profile-builder-mailchimp/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - allow users to subscribe to your Mailchimp lists directly from the Register or Edit Profile forms
* [Campaign Monitor](http://www.cozmoslabs.com/add-ons/profile-builder-campaign-monitor/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - allow users to subscribe to your Campaign Monitor lists directly from the Register or Edit Profile forms
* [MailPoet](http://www.cozmoslabs.com/add-ons/mailpoet/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - allow users to subscribe to your MailPoet lists directly from the Register and Edit Profile forms
* [Field Visibility](http://www.cozmoslabs.com/add-ons/field-visibility/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - allows you to change the visibility options for the extra fields
* [bbPress](https://www.cozmoslabs.com/add-ons/bbpress/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - allows you to integrate Profile Builder with the popular forums plugin, bbPress.
* [Multi-Step Forms](https://www.cozmoslabs.com/add-ons/multi-step-forms/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - allow users to build multi-step forms for Registration and Edit Profile forms.
* [BuddyPress](https://www.cozmoslabs.com/add-ons/buddypress/?utm_source=wp.org&utm_medium=pb-description-page&utm_campaign=PBFree) - allows extending BuddyPress user profiles with Profile Builder user fields.


= Documentation =

Please visit the [documentation page](https://www.cozmoslabs.com/docs/profile-builder-2/) for this plugin

= Website =

For more details visit our [website](http://www.cozmoslabs.com/wordpress-profile-builder/)

= Profile Builder in your Language =
We're focusing on translating Profile Builder in as many languages as we can. So far, the translations for 10 languages are almost complete, but we still need help on a lot of other languages, so please join us at [translate.cozmoslabs.com.](http://translate.cozmoslabs.com/projects/profile-builder)
You will be able to download all the [available language packs](http://translate.cozmoslabs.com/projects/profile-builder) as well as help us translate Profile Builder in your language.

NOTE:
This plugin adds/removes user fields in the front-end. Both default and extra profile fields will be visible in the back-end as well.
	


== Installation ==

1. Upload the profile-builder folder to the '/wp-content/plugins/' directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Create a new page and use one of the shortcodes available. Publish the page and you're done!

== Frequently Asked Questions ==

= I navigated away from Profile Builder and now I can�t find it anymore; where is it? =

	Profile Builder can be found in the default menu of your WordPress installation below the �Users� menu item.

= Why do the default WordPress user fields still show up in the back-end? =

	Profile Builder can only remove the default user fields in the front-end of your site/blog, it doesn't remove them from the back-end.

= I can’t find a question similar to my issue; Where can I find support? =

	For more information please visit http://www.cozmoslabs.com and check out the documentation section from Profile Builder - front-end user registration plugin.


== Screenshots ==
1. Basic Information - Profile Builder, front-end user registration plugin
2. General Settings - Profile Builder, front-end user registration plugin
3. Show/Hide Admin Bar
4. Profile Builder - Manage Default User Fields (Add, Edit or Delete)
5. Profile Builder - Drag & Drop to Reorder User Profile Fields
6. Register Form - Front-end User Registration Page
7. User Login Page
8. Edit User Profile Page
9. Recover Password Page
10. Profile Builder Login Widget
11. Role Editor Listing
12. Role Editor

== Changelog ==
= 2.7.2 =
* Updated translation file.
* Fixed issue with login token generating duplicated ID validation error

= 2.7.1 =
* Fixed an issue with the Biographical Info field that was showing html tags
* Fixed Content Restriction preview post before more-tag issue
* Fixed Roles Editor conflict with Dokan plugin
* Fixed redirect_priority='top' not working after login
* Fixed back-end login with after login redirect set to http_referer

= 2.7.0 = 
* Added [wppb-restrict] shortcode for Content Restriction
* Password Strength Indicator improvements
* Added an extra filter (wppb_mail) to wppb_mail function that gives the possibility to also send headers
* Updated German translation files.
* Added context to the 3 wppb_mail calls so we can identify the recover password emails being sent using the filters/actions from wppb_mail.
* Fixed content restriction meta-box for attachments

= 2.6.9 =
* Implemented Content Restriction feature
* Added nonce field on Profile Builder login form for security check
* Security improvements on login form
* Fixed an issue with po file-names that was causing random issues with different environments/FTP clients.
* Fixed a redirect loop when we log in from Paid Member Subscribtions and we had a redirect for default WordPress login
* Changed the locale for the Slovenian translation files. It was using the locale for Sierra Leone.

= 2.6.8 =
* Edit other users dropdown on the frontend Edit Profile form is now a select2
* Fixed a potential error when submitting the Register form

= 2.6.7 =
* Added option in backend user new/edit screen to add multiple user roles when user roles module is active
* Added user role multiple select for admin in front-end edit profile form when roles editor is active and select role field is in the form
* Changed password reset success email

= 2.6.6 =
* Updated translation files
* Added the wppb_fields_extra_css_class filter to default fields

= 2.6.5 =
* Fixed an issue where certain users could view the Roles Editor page without permission
* Changed the strings in Recover Password accordingly with the option set in 'Allow Users to Log in With' setting

= 2.6.4 =
* Fixed a bug which was preventing deleting thrashed posts
* Compatibility fixes with Advanced Custom Fields Plugin

= 2.6.3 =
* Fixed a small display bug for custom capabilities on Roles Editor
* Fixed a potential warning with the login form and WPML when cURL was not working properly

= 2.6.2 =
* Added Role Editor which grants you control over roles and capabilities on your site.
* Added reacaptcha field for Profile Builder forms and WordPress default forms
* Added User Role select field
* We now prevent our forms from executing in the header on the wp_head hook to prevent conflicts with other plugins like Yoast SEO
* Improved WPML compatibility with login forms
* Now checkboxes retain their value on edit profile forms if the form errors out
* Changed the way we set the default settings that was sometimes not adding them properly

= 2.6.1 =
* Updated translation files
* Added a filter for already logged in message on recover password form: wppb_recover_password_already_logged_in
* We now process only the submitted form so we can have multiple forms on the same page

= 2.6.0 =
* Compatibility with WPML for login widget/shortcode error messages
* Small change to meta name generation function that could eliminate a notice on some setups
* Updated translation files

= 2.5.9 =
* Fixed a issue with a database error that happened in certain conditions
* Compatibility with Captcha by BestWebSoft latest version

= 2.5.8 =
* Fixed security issues and performed a security audit

= 2.5.7 =
* Fixed an issue with "Display name as" field on register forms
* Recover password form now doesn't appear for logged in users
* Fixed a wrong variable passed to a filter in Email Confirmation

= 2.5.6 =
* Compatibility fix with php 7.1
* Redirects code refactoring which should fix some minor issues with redirects as well

= 2.5.5 =
* Added Blog Details field type
* Email From Name and Subject should now display proper special characters in all cases
* Fix css issue with notice image on forms taking an inherit width instead of auto
* Fixed an issue with automatic login with redirect on Firefox

= 2.5.4 =
* CSS changes for the Twenty Seventeen theme
* Fixed a notice caused sometimes by general settings option not setting properly
* Small changes to readme file

= 2.5.3 =
* Major improvement to loading performance of the Manage Fields admin interface
* Added actions before and after submit form button:wppb_form_before_submit_button and wppb_form_after_submit_button
* Added a filter on the forms submit button class
* Updated Dutch translations

= 2.5.2 =
* Updated translation files
* Added a filter to the submit button which can be used to add extra attributes: wppb_form_submit_extra_attr
* Fixed a warnings inside pb-compatiblities.php file
* Changed text for Email Confirmation description in admin area
* Fixed a bug with the "Add field" button in Manage Fields that wasn't disabled after we added a field
* Reorganized and added filters on form id and form class on hte Profile Builder forms
* Removed Note message from PMS cross promotion saying that PMS does not work with admin approval / email confirmation
* Modified multiple filters

= 2.5.1 =
* Improvements regarding caching plugins and user registration
* Added a search field in the admin area on the Users with unconfirmed email address screen
* Improved queries for displaying users in the admin area on the Users with unconfirmed email address screen

= 2.5.0 =
* We now delete cache when updating a user with email confirmation so solve issues with cache-ing plugins
* Fixed select2 JS error when select2 addon is inactive but select2 fields are still in front-end.
* Fixed js issues in manage fields interface when opened multiple fields for editing: sorting was possible and it shouldn't, the first opened field disappeared, a stack limit exceeded error

= 2.4.9 =
* Security improvements and fixes
* Fixed a warning that happened on older WordPress versions regarding the get_user_by() function
* Login with email uses default functions now for WordPress versions higher thab 4.5
* Removed login with email when username is selected from settings
* Removed sending password from default registration email

= 2.4.8 =
* Now when an administrator registers an user the Register button text has changed to Add User
* Multiple fixes regarding redirects
* Fixed issues with redirect_url shortcode parameter and changed the logout shortcode parameter to redirect_url from redirect
* Added the filter 'wppb_edit_other_users_dropdown_query_args' for changing the user query on the edit other users dropwdown

= 2.4.7 =
* Fixed an issue with the redirect after registration autologin and string translations
* Changes to Addons page to meet wp directory requirements
* Fixed a bug with forms on static front pages and the username field

= 2.4.6 =
* CSS modifications to accomodate dark/black themes
* Small changes for E-mail Confirmation and Paid Member Subscriptions compatibility

= 2.4.5 =
* Modifications to Addons Page
* Apply filter to email on all forms to allow stripping slashes if necessary
* Added filter so we can bypass Email Confirmation when needed
* New menu icon and small branding changes

= 2.4.4 =
* Added New branding images
* Added -required- html tag to fields
* Created function to return field based on id or meta_name
* Renamed HTML ID for recover-password div, to avoid duplicate IDs

= 2.4.3 =
* When login with email we remove the li for the username field now
* Small code review changes
* PHP 7.0 compatibility code review
* Define filter in wck-api for adding support for custom field types

= 2.4.2 =
* Edit profile double redirects after submitting changes
* Fix XSS security issues

= 2.4.1 =
* Security update for ajax calls

= 2.4.0 =
* Now we check checkboxes default value to not be empty in the front end forms
* Display name with email confirmation now is set to First name Last name or Nickname if they exist
* UI adjustment for checkbox in email confirmation table in the admin area

= 2.3.9 =
* Security update

= 2.3.8 =
* Fixed an issue with the redirect parameter for login widget
* Added extra_attr filter for recover password forms: 'wppb_recover_password_extra_attr'
* Added filter in select fields for placeholder labels add-on support
* Fixed the cozmoslabs.com url from http to https

= 2.3.7 =
* Changed the wppb_curpageurl function to fix the missing www problem from links
* Added a new filter wppb_send_to_admin_email to Email Confirmation

= 2.3.6 =
* Fixed a security issue regarding shortcodes
* Fixed a deprecated function warning in the hidden input field
* Fixed a notice in the WCK API
* Fixed a compatibility issue with ACF Pro
* We now make sure we call jQuery dialog only if it exists

= 2.3.5 =
* Fixed issue regarding password update not working in certain cases
* Changed label for when login with username is selected
* Fixed small css issue regarding checkboxes labels

= 2.3.4 =
* We now load the plugin translation from the current theme in the folder local_pb_lang if it exists otherwise normally from the plugin dir
* Fixed notices regarding the 'add_meta_box' hook
* Added a filter in wordpress-creation-kit API before testing for required fields: 'wck_before_test_required'
* Added hook before saving fields: 'wppb_before_saving_form_values'

= 2.3.3 =
* Added more fields to be available in wpml string translations: labels, default value and default content
* Made css modifications so that Checkbox, Radio and Select fields align properly in Twenty Sixteen theme
* Fixed different notices and warnings that appeared in certain cases

= 2.3.2 =
* When upgrading from an older version than 2.2.6 on a Multisite install Email Confirmation is set to yes automatically now
* Fixed notice undefined variable from wppb_mail when using filter to not send email
* Fixed filter wppb_curpageurl not being applied

= 2.3.1 =
* Refactored username exists check to search only in username
* Fixed issue when there was a meta in the db with no meta key and we couldn't add our fields that had no meta key because it would generate meta name already in use
* Fixed conflict with WPMUDEV Set Password plugin with which we had a function with the same name

= 2.3.0 =
* Added filter in login form so we can display html at the bottom
* Fixed a filter in login redirect link that was broken
* Removed 'Display name publicly as' from Registration Forms.
* We no longer create custom directories in the WordPress uploads directory.
* Removed notice from Manage Fields page when the WPML  plugin was active.

= 2.2.9 =
* Fixed compatibility with Yoast and Page Builder by SiteOrigin that caused our shortcodes to be executed multiple times

= 2.2.8 =
* Translation Updates
* Changed User Registered date and time according to timezone selected in WordPress settings

= 2.2.7 =
* Translation Updates

= 2.2.6 =
* Email Confirmation can now be disabled on WordPress multisite

= 2.2.5 =
* Fixed issue that prevented  the value 0 to be set as default value
* Fixed xss vulnerability
* Fixed issue that was preventing to change back to original email address in edit-profile, after changing to a new one
* Removed default value option from PB Password and Repeat Password fields
* Changed name of japanese translation file
* Fixed updating edit-profile form without email field, when allowing users to login only with email

= 2.2.4 =
* Translation Updates

= 2.2.3 =
* Fixed website field not saving on registering with email confirmation
* Fixed a potential security vulnerability
* Removed condition in edit-users dropdown to allow custom ones

= 2.2.2 =
* Fixed notice that was thrown in WordPress 4.3 related to WP_Widget constructor being deprecated in login widget.

= 2.2.1 =
* Changed recover password link from using username to using the user-nicename
* We no longer strip spaces from usernames on singele-site registration when Email Confirmation is on and we also do not allow usernames with spaces on multisite installs
* Changed message in Manage Fields sidebar
* Fixed issue that prevented sometimes 0 values to be saved

= 2.1.9 =
* Add attribute filter to each Profile Builder form input: apply_filters( 'wppb_extra_attribute', '', $field )
* Added Japanese translation
* Updated translation files

= 2.1.8 =
* Added filter to wppb_curpageurl() function to easily modify returned URL: apply_filters('wppb_curpageurl', $pageURL)
* Fixed a issue with default fields not having labels and descriptions localized sometimes
* Removed link to author page in logged in user shortcode
* Shortcodes on Basic Info page should no longer be translated
* Replaced home_url with site_url in login.php
* Fixed an error when admin was editing another user from the front end sometimes we got 'This email is already reserved to be used soon.'
* Select a User to edit (as admin) adds HTML special char (&amp;) in URL when should not
* Added filters that can be used to stop emails being sent to users or admins
* Redirect registration form after login to same page. Also added a filter on the url


= 2.1.7 =
* Added reCaptcha support for default login, register and lost password forms as well as PB forms + our own login widget
* Added RTL support for Profile Buider Forms
* Fixed a problem regarding required fields
* Added filter on add custom field values on user signup 'wppb_add_to_user_signup_form_meta'
* Fixed issue where username was sent instead of email when Login with Email was set in the user emails

= 2.1.6 =
* Updated translation files.
* Bulk approve email in Email Confirmation now functions as expected
* Now the Addons Page in Profile Builder is compatible with Multisite.
* Added filter to add extra css classes directly on the fields input: apply_filters( 'wppb_fields_extra_css_class', '', $field )
* The Show Meta button in the Email Confirmation admin screen no longer throws js errors when site in other language.
* Fixed bug that was preventing Checkboxes, Selects and Radios to not save correctly if they had special chars in their values

= 2.1.5 =
* Added compatibility with "Captcha" plugin
* Fixed issue on Add-Ons Page that prevented addons to be activated right after install
* Fixed issue on multisite where Adminstrator roles were able to edit other users from frontend
* Added filters to edit other users dropdown:'wppb_display_edit_other_users_dropdown' and 'wppb_edit_profile_user_dropdown_role'

= 2.1.4 =
* Fixed vulnerability regarding activating/deactivationg addons through ajax. We added nonces and permission checks.
* Added a filter in which we can change the classes on the li element for fields: 'wppb_field_css_class'
* Fixed automatic login on registration when filtering the random username generated when login with email is active

= 2.1.3 =
* Fixed bug that prevented non-administrator roles to save fields in their profile on the admin area
* Added Spanish translation
* Styled the alerts and errors in registration/edit profile, above the forms
* Added line in footer that asks users to leave a review if they enjoyed the plugin
* Fixed bug in registration forms that allowed users to create accounts even when they removed the email box from the DOM
* Fixed bug that was outputting wrong successful user registration message on multisite
* We now can add fields from Addons that will save on user activation
* Now WPPB_PLUGIN_DIR is pointing to the correct directory

= 2.1.2 =
* Created Add-On Page in Profile Builder
* Added support for Twenty Fifteen theme to better target inputs
* Add support for "redirect_url" parameter to Login shortcode (will do the same thing as "redirect" - for consistency)
* Added "redirect_url" parameter to Register and Edit-profile shortcodes

= 2.1.1 =
* Added username validation for illegal characters
* Fixed wp_mail() From headers being set sitewide

= 2.1.0 =
* Added option to Log In with either Username or Email.
* Added default values for "Logout" shortcode so it displays even if you don't pass any arguments to it.

= 2.0.9 =
* Fixed bug that was causing the username to be sent instead of the email when login with email was set to true in the default registration emails.
* Fixed bug in Password Reset email when Login with email was on.
* The "This email is already reserved to be used soon" error wasn't appearing on single site when Email Confirmation was on. Now it does when it is the case.
* Fixed bug that was causing an upload incompatibility with WordPress media uploader.
* Fixed bug that was causing Password strength and Password length error messages to not be translatable.
* Interface changes to forms in admin area on Profile Builder Pages.
* Added possibility to edit other users from the front end edit form when an admin is logged in.
* Added a popup in unconfirmed email user listing in admin area where the admin can see the users meta information.
* Add logout shortcode and menu link to Profile Builder.

= 2.0.8 =
* Fixed problem that when Email Confirmation was active the password in the registration emails was empty. We now have a placeholder for when we can't send the actual password.
* Added 'wppb_login_form_args' filter to filter wp_login_form() arguments.
* Added css classes to loged in message links so we can style.
* Fixed bug that was allowing us to change meta_name on un-editable fields:First Name, Last Name etc.
* Fixed "Display Name Publicly as” field on front-end.
* Now User Email Confirmation works on multisite as expected.
* Fixed bug that was throwing “This email is already reserved to be used soon” ERROR on Edit Profile form on multisite.
* Fixed bug that caused metaboxes and the Profile Builder page to appeared for roles that shouldn't have.

= 2.0.7 =
* Added icon with tooltip on registration pages 'Users can register themselves or you can manually create users here' message
* Updated translation files
* Removed some php notices from the code-base
* Improved theme compatibility for the submit buttons inside the Profile Builder forms
* Removed UL dots from Register form in Chrome, Safari

= 2.0.6 =
* Fixed a bug with checkbox field that didn't pass the required if the value of the checkbox contained spaces
* When email confirmation is enabled we no longer can send the selected password via email because we now store the hased password inside wp-signups table and not a encoded version of it. This was done to improve security
* Fixed problem that was causing "Insert into post" image button not to work
* Fixed Fatal error when having both Free and Premium versions activated.
* Removing the meta name for extra fields is no longer possible
* Added translation files


= 2.0.5 =
* Added notification to enable user registration via Profile Builder (Anyone can register checkbox).
* Add register_url and lostpassword_url parameters to login shortcode.
* Added filter to allow changing Lost Password link in login shortcode.

= 2.0.4 =
* Added $account_name as a parameter in the wppb_register_success_message filter
* Fixed typo in password strength meeter.

= 2.0.3 =
* Fixed bug that made radio buttons field types not to throw error when they are required
* Fixed XSS security vulnerability in fallback-page.php
* Reintroduced the filters:'wppb_generated_random_username', 'wppb_userlisting_extra_meta_email' and 'wppb_userlisting_extra_meta_user_name'
* Fixed the bug when changing the password in a edit profile form we were logged out

= 2.0.2 =
* Brand new user interface.
* Drag & drop to reorder User Profile Fields.
* More flexibility for Managing Default User Fields.
* Better Security by Enforcing Minimum Password Length and Minimum Password Strength on all forms (front-end and back-end).
* NOTE: upgrading from Profile Builder 1.1.x to 2.0.2 might make some of your plugin customization (if you have any ) not work because in the restructuring we had to drop some of the filters from 1.1.x.

= 1.1.67 =
* Added stripslashes to register shortcode.

= 1.1.66 =
* Sanitized forms against XSS exploits.

= 1.1.65 =
* Minor changes in the readme and index files.

= 1.1.64 =
* Minor changes in the readme and index files.

= 1.1.63 =
* Changes weren't saving on the Edit Profile page when profile was not fully updated.

= 1.1.62 =
* Minor changes to the readme file.

= 1.1.61 =
* Fixed a few notices in the plugin.

= 1.1.60 =
* Emergency security update regarding the password recovery feature.

= 1.1.59 =
Improved some of the queries meant to select users at certain points, hidden input value on front-end (Pro version) and the remember me checkbox on the login page.

= 1.1.58 =
Small changes to the index.php file

= 1.1.57 =
Fixed some bugs which only appeared in WPMU sites.

= 1.1.57 =
Minor changes to the readme.txt file.

= 1.1.56 =
Added activation_url and activation_link to the "Email Customizer" feature (pro). Also, once the "Email Confirmation" feature is activated, an option will appear to select the registration page for the "Resend confirmation email" feature, which was also added to the back-end userlisting.

= 1.1.55 =
Minor changes in the plugin's readme file and updated the screenshots.

= 1.1.54 =
Minor changes in the plugin's readme file.

= 1.1.53 =
Minor changes in the plugin's readme file.

= 1.1.52 =
Minor changes in the plugin's readme file.

= 1.1.51 =
Minor changes in the plugin's readme file.

= 1.1.50 =
Improved the userlisting feature in the Pro version.

= 1.1.49 =
Fixed "Edit Profile" bug and impred the "Admin Approval" default listing (in the paid versions).

= 1.1.48 =
Improved a few existing features (like WPML compatibility), and added a new feature: login with email address.

= 1.1.47 =
Improved the "Email Confirmation" feature and a few other functions.
Added new options for the "Userlisting" feature (available in the Pro version of Profile Buildeer).
Added translations: persian (thanks to Ali Mirzaei, info@alimir.ir)

= 1.1.46 =
Improved a few existing functions.

= 1.1.45 =
Fixed a few warnings on the register page.

= 1.1.44 =
Minor changes to the readme file.

= 1.1.43 =
Activation bug fixed.

= 1.1.42 =
Added a few improvements and fixed a few bugs.

= 1.1.41 =
Email Confirmation bug on WPMU fixed.

= 1.1.40 =
Minor changes to the readme file.

= 1.1.39 =
Security issue fixed regarding the "Email Confirmation" feature

= 1.1.38 =
Added a fix (suggested by http://wordpress.org/support/profile/maximinime) regarding the admin bar not displaying properly in some instances.

= 1.1.37 =
Minor changes to the readme file.

= 1.1.36 =
Minor changes to the readme file.

= 1.1.35 =
Added support for WP 3.5

= 1.1.34 =
Separated some of the plugin's functions into separate files. Also fixed a few bugs.

= 1.1.33 =
Fixed function where it wouldn't create the _signups table in the free version.

= 1.1.32 =
Error fixed.

= 1.1.31 =
Minor updates to the plugin files.

= 1.1.30 =
Minor changes to the plugin.

= 1.1.29 =
Minor changes to the readme file.

= 1.1.28 =
Changes to the readme file.

= 1.1.27 =
Fixed few warnings.

= 1.1.26 =
Minor changes

= 1.1.25 =
Different security issues fixed with other updates.

= 1.1.24 = 
Wordpress 3.3 support

= 1.1.23 =
Consecutive bugfixes.

= 1.1.14 =
Compatibility fix for WP version 3.3

= 1.1.13 = 
Minor changes to different parts of the plugin. Also updated the english translation.

= 1.1.12 = 
Minor changes to readme file.

= 1.1.11 = 
Minor changes to readme file.

= 1.1.10 = 
Minor changes to readme file.

= 1.1.9 = 
Minor changes to readme file.

= 1.1.8 =
Added the possibility to set the default fields as required (only works in the front end for now), and added a lot of new filters for a better and easier way to personalize the plugin. Also added a recover password feature (shortcode) to be in tune with the rest of the theme.
Added translations:
*italian (thanks to Gabriele, globalwebadvices@gmail.com)
*updated the english translation

= 1.1.7 =
Minor modification in the readme file.

= 1.1.6 =
Minor upload bug on WP repository. 

= 1.1.5 =
Added translations:
*czech (thanks to Martin Jurica, martin@jurica.info)
*updated the english translation

= 1.1.4 =
Added the possibility to set up the default user-role on registration; by adding the role="role_name" argument (e.g. [wppb-register role="editor"]) the role is automaticly set to all new users. 
Added translations:
*norvegian (thanks to Havard Ulvin, haavard@ulvin.no)
*dutch (thanks to Pascal Frencken, pascal.frencken@dedeelgaard.nl)
*german (thanks to Simon Stich, simon@1000ff.de)
*spanish (thanks to redywebs, www.redywebs.com) 
 

= 1.1.3 =
Minor bugfix.

= 1.1.2 =
Added translations to: 
*hungarian(thanks to Peter VIOLA, info@violapeter.hu)
*french(thanks to Sebastien CEZARD, sebastiencezard@orange.fr)

Bugfixes/enhancements:
*login page now automaticly refreshes itself after 1 second, a little less annoying than clicking the refresh button manually
*fixed bug where translation didn't load like it should
*added new user notification: the admin will now know about every new subscriber
*fixed issue where adding one or more spaces in the checkbox options list, the user can't save values.


= 1.1 =
Added a new user-interface (borrowed from the awesome plugin OptionTree created by Derek Herman), and bugfixes.

= 1.0.10 =
Bugfix - The wp_update_user attempts to clear and reset cookies if it's updating the password.
 Because of that we get "headers already sent". Fixed by hooking into the init.

= 1.0.9 =
Bugfix - On the edit profile page the website field added a new http:// everytime you updated your profile.
Bugfix/ExtraFeature - Add support for shortcodes to be run in a text widget area.

= 1.0.6 =
Apparently the WordPress.org svn converts my EOL from Windows to Mac and because of that you get "The plugin does not have a valid header."

= 1.0.5 =
You can now actualy install the plugin. All because of a silly line break.

= 1.0.4 =
Still no Change.

= 1.0.3 =
No Change.

= 1.0.2 =
Small changes.

= 1.0.1 =
Changes to the ReadMe File

= 1.0 =
Added the posibility of displaying/hiding default WordPress information-fields, and to modify basic layout.

== Upgrade Notice ==

= 2.0.0 =
Plugin overhaul. Introduces new interface. Please upgrade.